const inputEl = document.getElementById('todo-input');
const addBtn = document.getElementById('add-btn');
const listEl = document.getElementById('todo-list');

let todos = JSON.parse(localStorage.getItem('todos')) || [];

function save() {
  localStorage.setItem('todos', JSON.stringify(todos));
}

function render() {
  listEl.innerHTML = '';
  todos.forEach((task, i) => {
    const li = document.createElement('li');
    li.className = task.done ? 'completed' : '';
    const span = document.createElement('span');
    span.textContent = task.text;
    span.onclick = () => {
      todos[i].done = !todos[i].done;
      save();
      render();
    };
    const delBtn = document.createElement('button');
    delBtn.textContent = '✖';
    delBtn.onclick = () => {
      todos.splice(i, 1);
      save();
      render();
    };
    li.append(span, delBtn);
    listEl.appendChild(li);
  });
}

addBtn.addEventListener('click', () => {
  const text = inputEl.value.trim();
  if (!text) return;
  todos.push({ text, done: false });
  inputEl.value = '';
  save();
  render();
});

render();
