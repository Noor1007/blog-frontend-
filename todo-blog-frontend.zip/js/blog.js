const titleEl = document.getElementById('post-title');
const contentEl = document.getElementById('post-content');
const postBtn = document.getElementById('post-btn');
const postsSection = document.getElementById('posts');

let posts = JSON.parse(localStorage.getItem('posts')) || [];

function savePosts() {
  localStorage.setItem('posts', JSON.stringify(posts));
}

function renderPosts() {
  postsSection.innerHTML = '';
  posts.slice().reverse().forEach((post, revIndex) => {
    const i = posts.length - 1 - revIndex;
    const div = document.createElement('div');
    div.className = 'post';
    const h2 = document.createElement('h2');
    h2.textContent = post.title;
    const p = document.createElement('p');
    p.textContent = post.content;
    const actions = document.createElement('div');
    actions.className = 'post-actions';

    const editBtn = document.createElement('button');
    editBtn.textContent = 'Edit';
    editBtn.className = 'edit';
    editBtn.onclick = () => {
      const newTitle = prompt('New Title:', post.title);
      const newContent = prompt('New Content:', post.content);
      if (newTitle !== null && newContent !== null) {
        posts[i] = { title: newTitle, content: newContent };
        savePosts();
        renderPosts();
      }
    };

    const delBtn = document.createElement('button');
    delBtn.textContent = 'Delete';
    delBtn.className = 'delete';
    delBtn.onclick = () => {
      if (confirm('Delete this post?')) {
        posts.splice(i, 1);
        savePosts();
        renderPosts();
      }
    };

    actions.append(editBtn, delBtn);
    div.append(h2, p, actions);
    postsSection.appendChild(div);
  });
}

postBtn.addEventListener('click', () => {
  const title = titleEl.value.trim();
  const content = contentEl.value.trim();
  if (!title || !content) return;
  posts.push({ title, content });
  titleEl.value = '';
  contentEl.value = '';
  savePosts();
  renderPosts();
});

renderPosts();
